## ----echo=FALSE, message=FALSE, warning=FALSE---------------------------------
base_path <- "/Users/kylekimler/gitHub/workshops/"
data_loc <- paste0(base_path, "beginners-guide-to-analyzing-scRNAseq/data/")

## ----setup, message=FALSE, warning=FALSE, echo=TRUE---------------------------
library(Seurat)
library(SETA)
library(ggplot2)
library(wesanderson)
library(dplyr)
library(DT)

# Modify the file path if needed
seurat_file <- paste0(data_loc, "Covid_Flu_Seurat_Object_DF.rds")
seurat_obj <- readRDS(seurat_file)

## ----data wrangling, message=FALSE, warning=FALSE, echo=TRUE------------------
# Extract the taxonomic counts matrix using custom metadata column names
# (Users can specify these column names according to their dataset.)
taxa_counts <- setaCounts(seurat_obj,
                          cell_type_col = "Celltype",
                          sample_col = "Sample ID")
print(taxa_counts)

## ----transformation, echo=TRUE------------------------------------------------
# CLR Transformation with a pseudocount of 1 (default)
clr_out <- setaCLR(taxa_counts, pseudocount = 1)
DT::datatable(clr_out$counts)

# ALR Transformation: using "NK cell" as the reference cell type
if ("NK cell" %in% rownames(taxa_counts)) {
  alr_out <- setaALR(taxa_counts, ref = "NK cell", pseudocount = 1)
  DT::datatable(alr_out$counts)
} else {
  message("Reference 'NK cell' not found in taxa_counts. 
            Please choose an available cell type.")
}

# ILR Transform using Helmert basis (boxcox_p = 0 for standard ILR)
# This is the method used by Cacoa (Viktor Petukhov & Kharchenko Lab)
ilr_out <- setaILR(taxa_counts, boxcox_p = 0, pseudocount = 1)
DT::datatable(ilr_out$counts)

# Simple Percentage Transform
pct_out <- setaPercent(taxa_counts)
DT::datatable(pct_out$counts)

# LogCPM (counts per 10k) Transform
lcpm_out <- setaLogCPM(taxa_counts, pseudocount = 1)
DT::datatable(lcpm_out$counts)

## ----latent spaces, echo=TRUE-------------------------------------------------
latent_pca <- setaLatent(clr_out, method = "PCA", dims = 5)
# PCA Latent Space Coordinates:
DT::datatable(latent_pca$latentSpace)
# Variance Explained:
print(latent_pca$varExplained)

## ----variance explained, message=FALSE, warning=FALSE, echo=TRUE--------------
ve_df <- data.frame(
  PC = factor(seq_along(latent_pca$varExplained), 
              levels = seq_along(latent_pca$varExplained)),
  VarianceExplained = latent_pca$varExplained
)

ggplot(ve_df, aes(x = PC, y = VarianceExplained)) +
  geom_bar(stat = "identity", fill = "steelblue") +
  labs(title = "Variance Explained by Principal Components",
       x = "Principal Component", y = "Variance Explained") +
  theme_minimal()

## ----loadings, message=FALSE, warning=FALSE, echo=TRUE------------------------
# Ensure loadings are available from PCA
if (!is.null(latent_pca$loadings)) {
  loadings_df <- as.data.frame(latent_pca$loadings)
  loadings_df$Celltype <- rownames(loadings_df)

  # Melt the loadings into long format for ggplot2
  library(reshape2)
  loadings_long <- melt(loadings_df, id.vars = "Celltype",
                        variable.name = "PC", value.name = "Loading")

  # For each PC, select top and bottom 5 based on absolute loading values
  library(dplyr)
  loadings_summary <- loadings_long %>%
    group_by(PC) %>%
    arrange(desc(abs(Loading))) %>%
    filter(row_number() <= 5 | row_number() >= n() - 4) %>%
    ungroup()

  ggplot(loadings_summary, aes(x = Loading, y = Celltype, label = Celltype)) +
    geom_point() +
    geom_text(hjust = 1.2, vjust = 0.5, size = 3) +
    facet_wrap(~PC, scales = "free_x") +
    labs(title = "Top and Bottom 5 Cell Types by Loadings for Each PC",
         x = "Loading", y = "Cell Type") +
    theme_minimal()
} else {
  message("No loadings information available for the chosen latent method.")
}

## ----PCA scatter--------------------------------------------------------------
# Extract latent space coordinates from PCA result.
pca_coords <- latent_pca$latentSpace

# Extract metadata
meta_df <- setaMetadata(seurat_obj,
                        sample_col = "Sample ID",
                        meta_cols = c("disease", "Severity"))

# Merge latent coordinates with metadata
pca_plot_df <- cbind(pca_coords, meta_df)

# Create the scatter plot
ggplot(pca_plot_df, aes(x = PC1, y = PC2, shape = disease, color = Severity)) +
  geom_point(size = 3) +
  scale_color_manual(
    values = wesanderson::wes_palette("Zissou1", 4, type = "continuous")
  ) +
  labs(title = "PCA Scatter Plot",
       x = "PC1", y = "PC2", shape = "Disease", color = "Severity") +
  theme_minimal()

## -----------------------------------------------------------------------------
sessionInfo()

