library(testthat)
library(SETA)
test_check("SETA")