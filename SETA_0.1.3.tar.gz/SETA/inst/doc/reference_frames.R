## ----setup, message=FALSE, warning=FALSE--------------------------------------
library(Seurat)
library(SETA)
library(ggplot2)
library(ggraph)
library(tidygraph)
library(dplyr)
library(wesanderson)
library(ggplot2)
library(patchwork)

## ----dirs, echo = FALSE-------------------------------------------------------
# Path to dataset (modify as needed)
base_path <- "/Users/kylekimler/gitHub/workshops/"
data_loc  <- paste0(base_path, "beginners-guide-to-analyzing-scRNAseq/data/")

## ----load data, warning = FALSE, message = FALSE------------------------------
seurat_file <- paste0(data_loc, "Covid_Flu_Seurat_Object_DF.rds")

seurat_obj <- readRDS(seurat_file)
# Inspect the cell types:
unique(seurat_obj@meta.data$Celltype)

## ----add lineage information--------------------------------------------------
# We'll make a small mapping from original Celltype -> broader 'Lineage'
lineage_map <- c(
  "NK cell"               = "NK cell",
  "CD4, EM-like"          = "T cells",
  "CD8, non-EM-like"      = "T cells",
  "classical Monocyte"    = "Monocytes",
  "B cell, IgG+"          = "B cells",
  "DC"                    = "DC",
  "CD8, EM-like"          = "T cells",
  "B cell, IgG-"          = "B cells",
  "intermediate Monocyte" = "Monocytes",
  "CD4, non-EM-like"      = "T cells",
  "Platelet"              = "Platelet",
  "nonclassical Monocyte" = "Monocytes",
  "Uncategorized1"        = "Uncategorized1",
  "RBC"                   = "RBC",
  "Uncategorized2"        = "Uncategorized2"
)

# Convert factor -> character, then index
seurat_obj@meta.data$Celltype <- as.character(seurat_obj@meta.data$Celltype)

# Add a new column in @meta.data named 'Lineage'
celltypes <- as.character(seurat_obj@meta.data$Celltype)
seurat_obj@meta.data$Lineage <- lineage_map[celltypes]

## ----create taxonomy DF-------------------------------------------------------
# We'll rename rownames of meta.data as 'bc'
# Usually, they are barcodes. Then we ensure
# we have columns for 'Celltype' and 'Lineage'.
seurat_obj@meta.data$bc <- rownames(seurat_obj@meta.data)

# We want a data frame that includes bc + 'Celltype' + 'Lineage'
# Then we'll pass it to setaTaxonomyDF
tax_df <- setaTaxonomyDF(
  obj = seurat_obj,
  resolution_cols = c("Lineage", "Celltype")
)
# Each row is a unique 'Celltype'.
# The last column 'Celltype' is the finer label.
# cols must be entered in order of increasing resolution (broadest to finest)
tax_df

## ----ggraph, message=FALSE, warning=FALSE-------------------------------------
# Create a tidygraph object using SETA built-in utils
tbl_g <- taxonomy_to_tbl_graph(tax_df, columns = c("Lineage", "Celltype"))

# Plot with ggraph
ggraph(tbl_g, layout = "tree") +
    geom_edge_diagonal2(aes(color = node.Lineage),
                        arrow = arrow(length = unit(2, "mm"))) +
    geom_node_text(aes(label = name), vjust = 1, hjust = 0.5) +
    scale_color_manual(values = wes_palette("Zissou1", 10, type = "continuous")) +
    theme_minimal(base_size = 12) +
    coord_flip() +
    expand_limits(x = 3)
    theme(legend.position = "none") +
    labs(title = "Celltype → Lineage Taxonomy")

## -----------------------------------------------------------------------------
# Create sample x celltype counts:
taxa_counts <- setaCounts(
    seurat_obj,
    cell_type_col = "Celltype",
    sample_col = "donor_id"
)

# We'll transform them with a 'Lineage' grouping.
# The taxonomyDF uses rownames = Celltype
# so that colnames(taxa_counts) align with rownames(tax_df).
refframe_out <- setaTransform(
    counts            = taxa_counts,
    method            = "CLR",
    taxonomyDF        = tax_df,
    taxonomy_col      = "Lineage",
    within_resolution = TRUE
)
refframe_out$within_resolution   # TRUE
refframe_out$grouping_var        # 'Lineage'

# Compare to a standard global CLR transform:
global_out <- setaTransform(taxa_counts, method = "CLR")

## -----------------------------------------------------------------------------
# A) Global CLR
latent_global <- setaLatent(global_out, method = "PCA", dims = 2)
pca_global <- latent_global$latentSpace
pca_global$sample <- rownames(pca_global)

# B) Within-Lineage CLR
latent_lineage <- setaLatent(refframe_out, method = "PCA", dims = 2)
pca_lineage <- latent_lineage$latentSpace
pca_lineage$sample <- rownames(pca_lineage)

# Merge with metadata
meta_df <- setaMetadata(seurat_obj, sample_col = "Sample ID",
                        meta_cols=c("disease", "Severity"))
pca_global <- left_join(pca_global, meta_df, by = c("sample" = "Sample ID"))
pca_lineage <- left_join(pca_lineage, meta_df, by = c("sample" = "Sample ID"))

# Plot side by side
p1 <- ggplot(pca_global, aes(x = PC1, y = PC2, color = disease)) +
  geom_point(size = 3) +
  labs(title = "Global CLR PCA", color = "Disease") +
  theme_minimal()

p2 <- ggplot(pca_lineage, aes(x = PC1, y = PC2, color = disease)) +
  geom_point(size = 3) +
  labs(title = "Within-Lineage CLR PCA", color = "Disease") +
  theme_minimal()

p1 + p2

